from TdP_collections.graphs.graph import Graph


class CompagniaAreaGraph(Graph):

    class NewVertex(Graph.Vertex):
        def __init__(self, x, tc):
            """Do not call constructor directly. Use Graph's insert_vertex(x)."""
            self._element = x
            #tempo da attendere in un aereporto prima di poter prendere un altro volo
            self._tc = tc

        def get_tc(self):
            #metodo per ritornare il tempo da aspettare in un aereoporto prima della prossima coincidenza
            return self._tc


    class NewEdge(Graph.Edge):

        def __init__(self, u, v, orario_partenza, orario_arrivo, posti_disponibili):
            #Verificare orario di arrivo sia maggiore di orario di partenza, cioè il tempo di volo deve essere positivo

            self._origin = u
            self._destination = v
            self._element = orario_arrivo-orario_partenza
            self._orario_partenza = orario_partenza
            self._orario_arrivo = orario_arrivo
            self._posti_disponibili = posti_disponibili

        def get_orario_partenza(self):
            return self._orario_partenza

        def get_orario_arrivo(self):
            return self._orario_arrivo

        def get_posti_disponibili(self):
            return self._posti_disponibili

        def get_origin(self):
            return self._origin

    def insert_vertex(self, x, tc):
        """Insert and return a new Vertex with element x."""
        if not isinstance(tc, float):
            raise TypeError("Il tempo di coincidenza deve essere float.")
        if tc < 0:
            raise ValueError("Il tempo di coincidenza deve essere positivo.")
        v = self.NewVertex(x,tc)
        self._outgoing[v] = {}
        if self.is_directed():
            self._incoming[v] = {}  # need distinct map for incoming edges
        return v

    def insert_edge(self, u, v, orario_partenza, orario_arrivo, posti_disponibili):
        """Insert and return a new Edge from u to v with auxiliary element x.

        Raise a ValueError if u and v are not vertices of the graph.
        Raise a ValueError if u and v are already adjacent.
        """
        if self.get_edge(u, v) is not None:  # includes error checking
            raise ValueError('u and v are already adjacent')
        if not isinstance(orario_arrivo, float) or not isinstance(orario_partenza, float):
            raise TypeError("gli orari devono essere float")
        if not isinstance(posti_disponibili,int):
            raise TypeError("i posti disponibili devono essere un intero")
        if orario_partenza > orario_arrivo:
            raise ValueError("l'orario di partenza del volo deve essere < orario di arrivo")
        if posti_disponibili < 0:
            raise ValueError("posti_disponibili deve essere maggiore di zero")
        e = self.NewEdge(u, v, orario_partenza, orario_arrivo, posti_disponibili)
        self._outgoing[u][v] = e
        self._incoming[v][u] = e

from utility.CompagniaAereaGraph import CompagniaAreaGraph

def _print_all_paths_util(g, u, d, complessivo, path, time_departure, time_travel, arrival_time=0, sorgente=True):  # o(2m)
    # Mark the current node as visited and store in path
    path.append(u)

    # If current vertex is same as destination, then print
    if u == d:
        for e in path:
            complessivo.append(e)
        complessivo.append("\n")
    #else:
    #if u != d:
        # If current vertex is not destination
        # Recur for all the vertices adjacent to this vertex
    else:
        for i in g.incident_edges(u):
            if sorgente and u.isGate() is False:

                #if arrival_time <= i.get_orario_partenza() and time_departure <= i.get_orario_partenza() and time_travel >= i.element():
                    #_print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure, time_travel - i.element(),
                                          #arrival_time=i.get_orario_arrivo(), sorgente=False)
                    _print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure, time_travel,
                                          arrival_time=i.get_orario_arrivo(), sorgente=True)

            elif sorgente and u.isGate():
                #se si parte da un gate della sorgente
                if arrival_time <= i.get_orario_partenza() and time_departure <= i.get_orario_partenza() and time_travel >= i.element():
                    #_print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure, time_travel - i.element(),
                                          #arrival_time=i.get_orario_arrivo(), sorgente=False)
                    _print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure, time_travel,
                                          arrival_time=i.get_orario_arrivo(), sorgente=False)

            #else
            elif sorgente is False:
                if u.isGate() is False:
                   # _print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure,
                                          #time_travel - i.element(),
                                          #arrival_time=i.get_orario_arrivo(), sorgente=False)
                   _print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure,
                                         time_travel - i.element(), arrival_time=arrival_time, sorgente=False)
                else:
                    if arrival_time + u.get_tc() <= i.get_orario_partenza() and time_travel >= i.element() + u.get_tc():
                        _print_all_paths_util(g, i.opposite(u), d, complessivo, path, time_departure, time_travel - (i.element() + u.get_tc()),
                                              arrival_time=i.get_orario_arrivo(), sorgente=False)

    # Remove current vertex from path[]
    path.pop()


# Prints all paths from 's' to 'd'
def list_routes(g, s, d, time_departure, time_travel):  #circa o(n+2m)
    # Create an array to store paths
    if s.isGate() or d.isGate():
        raise TypeError("Sorgente e destinazione devono essere aeroporti, non gate")
    path = []
    complessivo = []
    # Call the recursive helper function to print all paths
    _print_all_paths_util(g, s, d, complessivo, path, time_departure, time_travel)

    for c in complessivo:
        print(c)






from classe.CompagniaGraph import CompagniaGraph
from pkg2gruppo14.findroutegruppo14 import find_route
def testFindRoute():
    g = CompagniaGraph(True)

    a = g.insert_vertex("A", 1.0, False, "A")
    b = g.insert_vertex("B", 2.0, False, "B")
    c = g.insert_vertex("C", 3.0, False, "C")
    d = g.insert_vertex("D", 4.0, False, "D")
    e = g.insert_vertex("E", 5.0, False, "E")
    f = g.insert_vertex("F", 5.0, False, "F")


    a1 = g.insert_vertex("A1", 1.0, True, "A")
    b1 = g.insert_vertex("B1", 2.0, True, "B")
    b2 = g.insert_vertex("B2", 2.0, True, "B")
    c1 = g.insert_vertex("C1", 3.0, True, "C")
    d1 = g.insert_vertex("D1", 4.0, True, "D")
    e1 = g.insert_vertex("E1", 5.0, True, "E")


    #edge:  u, v, orario_partenza, orario_arrivo, posti_disponibili
    g.insert_edge(a, a1, 8.0, 10.0, 1)
    g.insert_edge(a1, b, 8.0, 10.0, 1)
    g.insert_edge(b, b1, 13.0, 14.0, 1)
    g.insert_edge(b1, c, 13.0, 14.0, 1)
    g.insert_edge(c, c1, 17.5, 19.0, 1)
    g.insert_edge(c1, d, 17.5, 19.0, 1)
    g.insert_edge(e, e1, 19.0, 22.0, 1)
    g.insert_edge(e1, d, 19.0, 22.0, 1)
    g.insert_edge(b, b2, 13.0, 15.0, 1)
    g.insert_edge(b2, e, 13.0, 15.0, 1)

    print("La rotta è:")
    find_route(g, a, d, 5.0)
    #print("_________________________")
    #find_route(g, a, d, 5.0)
    print("\n")
    print("Di tre rotte la più breve è:")


    jfk = g.insert_vertex("JFK", 1.0, False, "JFK")
    bos = g.insert_vertex("BOS", 3.0, False, "BOS")
    ord = g.insert_vertex("ORD", 4.0, False, "ORD")
    dfw = g.insert_vertex("DFW", 3.0, False, "DFW")
    mia = g.insert_vertex("MIA", 1.0, False, "MIA")

    jfk1 = g.insert_vertex("JFK1", 1.0, True, "JFK")
    jfk2 = g.insert_vertex("JFK2", 1.0, True, "JFK")
    bos1 = g.insert_vertex("BOS1", 3.0, True, "BOS")
    bos2 = g.insert_vertex("BOS2", 3.0, True, "BOS")
    bos3 = g.insert_vertex("BOS1", 3.0, True, "BOS")

    ord1 = g.insert_vertex("ORD1", 4.0, True, "ORD")
    ord2 = g.insert_vertex("ORD2", 4.0, True, "ORD")
    dfw1 = g.insert_vertex("DFW1", 3.0, True, "DFW")
    mia1 = g.insert_vertex("MIA1", 1.0, True, "MIA")


    g.insert_edge(jfk, jfk1, 6.0, 8.0, 5)
    g.insert_edge(jfk1, bos, 6.0, 8.0, 5)
    g.insert_edge(bos, bos1, 11.0, 16.0, 5)
    g.insert_edge(bos1, ord, 11.0, 16.0, 5)
    g.insert_edge(jfk, jfk2, 16.0, 17.0, 5)
    g.insert_edge(jfk2, ord, 16.0, 17.0, 5)
    g.insert_edge(bos, bos2, 17.0, 21.0, 5)
    g.insert_edge(bos2, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, bos3, 14.0, 20.0, 5)
    g.insert_edge(bos3, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, ord1, 13.0, 16.0, 5)
    g.insert_edge(ord1, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, dfw1, 15.0, 19.5, 5)
    g.insert_edge(dfw1, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, ord2, 8.0, 13.0, 5)
    g.insert_edge(ord2, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, mia1, 16.0, 19.0, 5)
    g.insert_edge(mia1, jfk, 16.0, 19.0, 5)

    find_route(g, jfk, ord, 5.0)

def dueDiretti():
    g = CompagniaGraph(True)

    a = g.insert_vertex("A", 1.0, False, "A")
    b = g.insert_vertex("B", 2.0, False, "B")
    c = g.insert_vertex("C", 3.0, False, "C")
    d = g.insert_vertex("D", 4.0, False, "D")
    e = g.insert_vertex("E", 5.0, False, "E")
    f = g.insert_vertex("F", 5.0, False, "F")

    a1 = g.insert_vertex("A1", 1.0, True, "A")
    a2 = g.insert_vertex("A2", 1.0, True, "A")
    b1 = g.insert_vertex("B1", 2.0, True, "B")
    b2 = g.insert_vertex("B2", 2.0, True, "B")
    c1 = g.insert_vertex("C1", 3.0, True, "C")
    d1 = g.insert_vertex("D1", 4.0, True, "D")
    e1 = g.insert_vertex("E1", 5.0, True, "E")

    # edge:  u, v, orario_partenza, orario_arrivo, posti_disponibili
    g.insert_edge(a, a1, 8.0, 10.0, 1)
    g.insert_edge(a1, b, 8.0, 10.0, 1)
    g.insert_edge(b, b1, 13.0, 14.0, 1)
    g.insert_edge(b1, c, 13.0, 14.0, 1)
    g.insert_edge(c, c1, 17.5, 19.0, 1)
    g.insert_edge(c1, d, 17.5, 19.0, 1)
    g.insert_edge(e, e1, 19.0, 22.0, 1)
    g.insert_edge(e1, d, 19.0, 22.0, 1)
    g.insert_edge(b, b2, 13.0, 15.0, 1)
    g.insert_edge(b2, e, 13.0, 15.0, 1)
    g.insert_edge(a, a2, 6.0, 7.0, 1)
    g.insert_edge(a2, d, 6.0, 7.0, 1)

    find_route(g, a, d, 5.0)
def nonRaggiungibile():
    g = CompagniaGraph(True)

    a = g.insert_vertex("A", 1.0, False, "A")
    b = g.insert_vertex("B", 2.0, False, "B")
    c = g.insert_vertex("C", 3.0, False, "C")
    d = g.insert_vertex("D", 4.0, False, "D")
    e = g.insert_vertex("E", 5.0, False, "E")
    f = g.insert_vertex("F", 5.0, False, "F")

    a1 = g.insert_vertex("A1", 1.0, True, "A")
    b1 = g.insert_vertex("B1", 2.0, True, "B")
    b2 = g.insert_vertex("B2", 2.0, True, "B")
    c1 = g.insert_vertex("C1", 3.0, True, "C")
    d1 = g.insert_vertex("D1", 4.0, True, "D")
    e1 = g.insert_vertex("E1", 5.0, True, "E")

    # edge:  u, v, orario_partenza, orario_arrivo, posti_disponibili
    g.insert_edge(a, a1, 8.0, 10.0, 1)
    g.insert_edge(a1, b, 8.0, 10.0, 1)
    g.insert_edge(b, b1, 13.0, 14.0, 1)
    g.insert_edge(b1, c, 13.0, 14.0, 1)
    g.insert_edge(c, c1, 17.5, 19.0, 1)
    g.insert_edge(c1, d, 17.5, 19.0, 1)
    g.insert_edge(e, e1, 19.0, 22.0, 1)
    g.insert_edge(e1, d, 19.0, 22.0, 1)
    g.insert_edge(b, b2, 13.0, 15.0, 1)
    g.insert_edge(b2, e, 13.0, 15.0, 1)

    # find_route(g, a, b, 9.0)
    # f non è raggiungibile

    find_route(g, a, f, 5.0)


if __name__ == "__main__":
    testFindRoute()
    print("\n")
    nonRaggiungibile()
    print("\n")
    print("Con più voli diretti: ")
    dueDiretti()
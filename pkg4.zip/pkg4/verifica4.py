from TdP_collections.graphs.graph import *
from pkg4.bipartite import *

def testBipartitoConnesso():
    g = Graph()
    a = g.insert_vertex("A")
    b = g.insert_vertex("B")
    c = g.insert_vertex("C")
    d = g.insert_vertex("D")
    e = g.insert_vertex("E")
    g.insert_edge(a, b)
    g.insert_edge(b, c)
    g.insert_edge(c, d)
    g.insert_edge(d, e)
    g.insert_edge(b, e)

    partizione = bipartite(g)

    if partizione is not None:
        for e in partizione:
            i = 0
            while i < len(e):
                print(e[i])
                i += 1
            print("-------------")
    else:
        print(partizione)

def testBipartiteNonConnesso():
    g = Graph()
    a = g.insert_vertex("A")
    b = g.insert_vertex("B")
    c = g.insert_vertex("C")
    d = g.insert_vertex("D")
    e = g.insert_vertex("E")
    g.insert_edge(a, b)
    g.insert_edge(b, c)
    g.insert_edge(c, d)
    g.insert_edge(d, e)
    g.insert_edge(b, e)
    
    m = g.insert_vertex("M")
    n = g.insert_vertex("N")
    o = g.insert_vertex("O")
    p = g.insert_vertex("P")
    q = g.insert_vertex("Q")
    g.insert_edge(m, n)
    g.insert_edge(n, o)
    g.insert_edge(o, p)
    g.insert_edge(p, q)
    g.insert_edge(n, q)

    partizione = bipartite(g)
    if partizione is not None:
        for e in partizione:
            i = 0
            while i < len(e):
                print(e[i])
                i += 1
            print("-------------")
    else:
        print(partizione)

def testNonBipartite():
    g = Graph()
    a = g.insert_vertex("A")
    b = g.insert_vertex("B")
    c = g.insert_vertex("C")
    d = g.insert_vertex("D")
    e = g.insert_vertex("E")
    g.insert_edge(a, b)
    g.insert_edge(b, c)
    g.insert_edge(c, d)
    g.insert_edge(d, e)
    g.insert_edge(b, e)
    g.insert_edge(a, c)

    partizione = bipartite(g)
    if partizione is not None:
        for e in partizione:
            i = 0
            while i < len(e):
                print(e[i])
                i += 1
            print("-------------")
    else:
        print(partizione)
if __name__ == "__main__":
    print("Grafo connesso")
    testBipartitoConnesso()
    print("Grafo non connesso bipartito")
    testBipartiteNonConnesso()
    print("Grafo non bipartito")
    testNonBipartite()


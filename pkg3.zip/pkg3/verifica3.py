from pkg3.selectflights import *

def test_budget_sufficiente():

    # budget in euro. Volo: 1h = 60 kg = 60 euro
    budget = 1390

    select_flights(g, budget)
def test_budget_insufficiente():
    # budget in euro. Volo: 1h = 60 kg = 60 euro
    budget = 39

    select_flights(g, budget)

def test_budget_parte_solo_uno():
    # budget in euro. Volo: 1h = 60 kg = 60 euro
    budget = 60

    select_flights(g, budget)

if __name__ == "__main__":
    g = CompagniaAreaGraph(True)

    a = g.insert_vertex("A", 1.0)
    b = g.insert_vertex("B", 2.0)
    c = g.insert_vertex("C", 3.0)
    d = g.insert_vertex("D", 4.0)
    e = g.insert_vertex("E", 5.0)

    # edge:  u, v, orario_partenza, orario_arrivo, posti_disponibili
    g.insert_edge(a, b, 8.0, 10.0, 50)
    g.insert_edge(b, c, 13.0, 14.0, 45)
    g.insert_edge(c, d, 17.5, 19.0, 40)
    g.insert_edge(d, e, 19.0, 22.0, 60)
    g.insert_edge(b, e, 13.0, 15.0, 30)

    test_budget_sufficiente()
    print("\n")
    test_budget_insufficiente()
    print("\n")
    test_budget_parte_solo_uno()

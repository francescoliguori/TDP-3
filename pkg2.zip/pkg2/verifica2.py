from utility.CompagniaAereaGraph import CompagniaAreaGraph
from pkg2.findroute import find_route
def testFindRoute():
    g = CompagniaAreaGraph(True)

    a = g.insert_vertex("A", 1.0)
    b = g.insert_vertex("B", 2.0)
    c = g.insert_vertex("C", 3.0)
    d = g.insert_vertex("D", 4.0)
    e = g.insert_vertex("E", 5.0)
    f = g.insert_vertex("F", 5.0)
    #edge:  u, v, orario_partenza, orario_arrivo, posti_disponibili
    g.insert_edge(a, b, 8.0, 10.0, 1)
    g.insert_edge(b, c, 13.0, 14.0, 1)
    g.insert_edge(c, d, 17.5, 19.0, 1)
    g.insert_edge(e, d, 19.0, 22.0, 1)
    g.insert_edge(b, e, 13.0, 15.0, 1)
    #find_route(g, a, b, 9.0)
    #f non è raggiungibile

    find_route(g, a, d, 5.0)
    #print("_________________________")
    #find_route(g, a, d, 5.0)

    print("Di tre rotte la più breve")
    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 4.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)

    # Tre rotte
    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    # g.insert_edge(bos, ord, 10.0, 16.0, 5)
    g.insert_edge(bos, ord, 11.0, 16.0, 5)
    # g.insert_edge(jfk, ord, 12.0, 13.0, 5)
    g.insert_edge(jfk, ord, 16.0, 17.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, jfk, 16.0, 19.0, 5)

    find_route(g, jfk, ord, 5.0)

if __name__ == "__main__":
    testFindRoute()
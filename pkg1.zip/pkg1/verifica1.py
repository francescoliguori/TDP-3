from utility.CompagniaAereaGraph import CompagniaAreaGraph
from pkg1.listroute import list_routes


def treRotte():
    g = CompagniaAreaGraph(True)

    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 4.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)

    #Tre rotte
    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    #g.insert_edge(bos, ord, 10.0, 16.0, 5)
    g.insert_edge(bos, ord, 11.0, 16.0, 5)
    #g.insert_edge(jfk, ord, 12.0, 13.0, 5)
    g.insert_edge(jfk, ord, 21.0, 24.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, jfk, 16.0, 19.0, 5)

    list_routes(g, jfk, ord, 5, 24)

def unaRotta():
    g = CompagniaAreaGraph(True)

    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 4.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)

    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    g.insert_edge(bos, ord, 10.0, 16.0, 5)
    #g.insert_edge(bos, ord, 11.0, 16.0, 5)
    g.insert_edge(jfk, ord, 12.0, 13.0, 5)
    #g.insert_edge(jfk, ord, 21.0, 24.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, jfk, 16.0, 19.0, 5)

    list_routes(g, jfk, ord, 7, 24)

def viaggioTroppoLungo():
    g = CompagniaAreaGraph(True)

    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 1.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)

    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    g.insert_edge(bos, ord, 10.0, 12.0, 5)
    # g.insert_edge(bos, ord, 11.0, 16.0, 5)
    g.insert_edge(jfk, ord, 9.0, 10.0, 5)
    # g.insert_edge(jfk, ord, 21.0, 24.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 11.0, 24.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, jfk, 16.0, 19.0, 5)

    #la diminuzione del tempo massimo di volo da 24 a 10 fa scartare le rotte che ci portano a Dallas
    list_routes(g, jfk, dfw, 5, 10)

def partenzaTroppoTardi():
    g = CompagniaAreaGraph(True)

    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 4.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)

    # Tre rotte
    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    # g.insert_edge(bos, ord, 10.0, 16.0, 5)
    g.insert_edge(bos, ord, 11.0, 16.0, 5)
    g.insert_edge(jfk, ord, 12.0, 13.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, jfk, 16.0, 19.0, 5)

    list_routes(g, jfk, ord, 13, 24)

def nonConnesso():
    g = CompagniaAreaGraph(True)

    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 4.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)
    flocco = g.insert_vertex("FL", 2.0)

    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    # g.insert_edge(bos, ord, 10.0, 16.0, 5)
    g.insert_edge(bos, ord, 11.0, 16.0, 5)
    # g.insert_edge(jfk, ord, 12.0, 13.0, 5)
    g.insert_edge(jfk, ord, 21.0, 24.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 8.0, 13.0, 5)
    g.insert_edge(mia, jfk, 16.0, 19.0, 5)

    list_routes(g, jfk, flocco, 5, 24)

def sorgenteDestinazione():
    g = CompagniaAreaGraph(True)

    jfk = g.insert_vertex("JFK", 1.0)
    bos = g.insert_vertex("BOS", 3.0)
    ord = g.insert_vertex("ORD", 2.0)
    dfw = g.insert_vertex("DFW", 3.0)
    mia = g.insert_vertex("MIA", 1.0)

    # Tre rotte
    g.insert_edge(jfk, bos, 6.0, 8.0, 5)
    # g.insert_edge(bos, ord, 10.0, 16.0, 5)
    g.insert_edge(bos, ord, 11.0, 16.0, 5)
    g.insert_edge(jfk, ord, 12.0, 13.0, 5)
    g.insert_edge(bos, mia, 17.0, 21.0, 5)
    g.insert_edge(bos, jfk, 14.0, 20.0, 5)
    g.insert_edge(ord, dfw, 13.0, 16.0, 5)
    g.insert_edge(dfw, bos, 15.0, 19.5, 5)
    g.insert_edge(ord, mia, 15.0, 18.0, 5)
    g.insert_edge(mia, jfk, 20.0, 22.0, 5)
    #g.insert_edge(jfk, jfk, 23.0, 23.2, 5)
    list_routes(g, jfk, jfk, 5, 24)

# sfo = g.insert_vertex("SFO", 6.0)
# lax = g.insert_vertex("LAX", 6.0)
# rom = g.insert_vertex("ROM", 6.0)
# mil = g.insert_vertex("MIL", 6.0)
# nap = g.insert_vertex("NAP", 6.0)

if __name__ == "__main__":
    print("Tre rotte su tre possibili")
    treRotte()
    print("Una rotta su tre possibili")
    unaRotta()
    print("Viaggio troppo lungo")
    viaggioTroppoLungo()
    print("\n")
    print("Si vuole partire troppo tardi")
    partenzaTroppoTardi()
    print("\n")
    print("Destinazione non raggiungibile")
    nonConnesso()
    print("\n")
    print("Sorgente e destinazione coincidono")
    sorgenteDestinazione()
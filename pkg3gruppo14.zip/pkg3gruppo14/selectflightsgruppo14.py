from classe.CompagniaGraph import CompagniaGraph


def find_sol(v, c, B, C):
    n = len(v)
    sol = list()
    while n-1 >= 0:
        if C[n-1][B]:
            sol.append(n-1)
            B = B-v[n-1]
        n -= 1
    return sol


def knapsack(volume, cost, B):
    n = len(volume)
    M = [[0 for k in range(B+1)] for i in range(n)]
    C = [[False for k in range(B+1)] for i in range(n)]
    for k in range(B+1):
        # trovo la posizione in tabella dove il solo elemento v[0] ci entra
        # da lì in poi copio nella tabella il suo costo
        if volume[0] <= k:
            M[0][k] = cost[0]
            C[0][k] = True
    for i in range(1, n):
        for k in range(B+1):
            if volume[i] <= k and M[i - 1][k - volume[i]] + cost[i] > M[i - 1][k]:
                M[i][k] = M[i-1][k - volume[i]] + cost[i]
                C[i][k] = True
            else:
                M[i][k] = M[i-1][k]

    # print("il v alore della table:\n")
    # for i in range(len(M)):
    #     print(M[i])
    # print("\n\n\n\n\n\n")
    # print("C vale:\n")
    # for i in range(len(C)):
    #     print(C[i])
    return M[n-1][B], find_sol(volume, cost, B, C)


def select_flights(g, budget):
    if not isinstance(g, CompagniaGraph):
        raise TypeError("g deve essere un CompagniaAreaGraph")
    if not isinstance(budget, int):
        raise TypeError("il budget deve essere un intero")
    if budget <= 0:
        raise ValueError("il budget deve essere > 0")
    gasolio, posti = [], []
    for e in g.edges():
        u,v = e.endpoints()
        if u.isGate() and v.isGate() is False:
            gasolio.append(int(e.element()*60))
            posti.append(e.get_posti_disponibili())
        #print(gasolio)
    #print(posti)
    n_posti, soluz = knapsack(gasolio, posti, budget)
    print(n_posti)
    #print(soluz)
    archi = []
    for e in g.edges():
        u, v = e.endpoints()
        if u.isGate() and v.isGate() is False:
            archi.append(e.get_origin())
    airport = {}
    if len(soluz) == 0:
        print("Non partono voli")
    else:
        for sol in soluz:
            key = archi[sol]
            key = str(key)[:len(str(key)) - 1]
            if key in airport.keys():
                airport[key] += gasolio[sol]
            else:
                airport[key] = gasolio[sol]
        for k in airport.keys():
            print("In airport:", k, "servono €:", airport[k])






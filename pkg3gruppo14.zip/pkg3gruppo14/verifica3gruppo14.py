from pkg3gruppo14.selectflightsgruppo14 import *

def test_budget_sufficiente():

    # budget in euro. Volo: 1h = 60 kg = 60 euro
    budget = 1390
    #budget = 300

    select_flights(g, budget)
def test_budget_insufficiente():
    # budget in euro. Volo: 1h = 60 kg = 60 euro
    budget = 39

    select_flights(g, budget)

def test_budget_parte_solo_uno():
    # budget in euro. Volo: 1h = 60 kg = 60 euro
    budget = 60

    select_flights(g, budget)
#def test_budget_altro_grafo():

if __name__ == "__main__":
    g = CompagniaGraph(True)

    a = g.insert_vertex("A", 1.0, False, "A")
    b = g.insert_vertex("B", 2.0, False, "B")
    c = g.insert_vertex("C", 3.0, False, "C")
    d = g.insert_vertex("D", 4.0, False, "D")
    e = g.insert_vertex("E", 5.0, False, "E")
    f = g.insert_vertex("F", 5.0, False, "F")

    a1 = g.insert_vertex("A1", 1.0, True, "A")
    b1 = g.insert_vertex("B1", 2.0, True, "B")
    b2 = g.insert_vertex("B2", 2.0, True, "B")
    c1 = g.insert_vertex("C1", 3.0, True, "C")
    d1 = g.insert_vertex("D1", 4.0, True, "D")
    e1 = g.insert_vertex("E1", 5.0, True, "E")

    # edge:  u, v, orario_partenza, orario_arrivo, posti_disponibili
    g.insert_edge(a, a1, 8.0, 10.0, 50)
    g.insert_edge(a1, b, 8.0, 10.0, 50)
    g.insert_edge(b, b1, 13.0, 14.0, 45)
    g.insert_edge(b1, c, 13.0, 14.0, 45)
    g.insert_edge(c, c1, 17.5, 19.0, 40)
    g.insert_edge(c1, d, 17.5, 19.0, 40)
    g.insert_edge(d, d1, 19.0, 22.0, 60)
    g.insert_edge(d1, e, 19.0, 22.0, 60)
    g.insert_edge(b, b2, 13.0, 15.0, 30)
    g.insert_edge(b2, e, 13.0, 15.0, 30)

    # g.insert_edge(a, a1, 8.0, 10.0, 5)
    # g.insert_edge(a1, b, 8.0, 10.0, 5) #2 ore
    # g.insert_edge(b, b1, 13.0, 14.0, 5)
    # g.insert_edge(b1, c, 13.0, 14.0, 5)#1 ora
    # g.insert_edge(c, c1, 17.5, 19.0, 5)
    # g.insert_edge(c1, d, 17.5, 19.0, 5)#1.5
    # g.insert_edge(d, d1, 19.0, 22.0, 5)
    # g.insert_edge(d1, e, 19.0, 22.0, 5)#3
    # g.insert_edge(b, b2, 13.0, 15.0, 5)
    # g.insert_edge(b2, e, 13.0, 15.0, 5)#2

    jfk = g.insert_vertex("JFK", 1.0, False, "JFK")
    bos = g.insert_vertex("BOS", 3.0, False, "BOS")
    ord = g.insert_vertex("ORD", 4.0, False, "ORD")
    dfw = g.insert_vertex("DFW", 3.0, False, "DFW")
    mia = g.insert_vertex("MIA", 1.0, False, "MIA")

    jfk1 = g.insert_vertex("JFK1", 1.0, True, "JFK")
    jfk2 = g.insert_vertex("JFK2", 1.0, True, "JFK")
    bos1 = g.insert_vertex("BOS1", 3.0, True, "BOS")
    bos2 = g.insert_vertex("BOS2", 3.0, True, "BOS")
    bos3 = g.insert_vertex("BOS1", 3.0, True, "BOS")

    ord1 = g.insert_vertex("ORD1", 4.0, True, "ORD")
    ord2 = g.insert_vertex("ORD2", 4.0, True, "ORD")
    dfw1 = g.insert_vertex("DFW1", 3.0, True, "DFW")
    mia1 = g.insert_vertex("MIA1", 1.0, True, "MIA")

    g.insert_edge(jfk, jfk1, 6.0, 8.0, 5)
    g.insert_edge(jfk1, bos, 6.0, 8.0, 5) #2 ore
    g.insert_edge(bos, bos1, 11.0, 16.0, 5)
    g.insert_edge(bos1, ord, 11.0, 16.0, 5)#5 ore
    g.insert_edge(jfk, jfk2, 16.0, 17.0, 5)
    g.insert_edge(jfk2, ord, 16.0, 17.0, 5)#1 ora
    g.insert_edge(bos, bos2, 17.0, 21.0, 5)
    g.insert_edge(bos2, mia, 17.0, 21.0, 5)#4 ore
    g.insert_edge(bos, bos3, 14.0, 20.0, 5)
    g.insert_edge(bos3, jfk, 14.0, 20.0, 5)#6 ore
    g.insert_edge(ord, ord1, 13.0, 16.0, 5)
    g.insert_edge(ord1, dfw, 13.0, 16.0, 5)#3 ore
    g.insert_edge(dfw, dfw1, 15.0, 19.5, 5)
    g.insert_edge(dfw1, bos, 15.0, 19.5, 5)#4.5 ore
    g.insert_edge(ord, ord2, 8.0, 13.0, 5)
    g.insert_edge(ord2, mia, 8.0, 13.0, 5)#5 ore
    g.insert_edge(mia, mia1, 16.0, 19.0, 5)
    g.insert_edge(mia1, jfk, 16.0, 19.0, 5)#3 ore



    test_budget_sufficiente()
    print("\n")
    test_budget_insufficiente()
    print("\n")
    test_budget_parte_solo_uno()
